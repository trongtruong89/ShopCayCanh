﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopCayCanh.Library
{
    public class Util
    {
        // email dung de gui di
        public static string email ="Tran van bao3339@gmail.com";
        //pass email
        public static string password = "proTran van bao77";
    }
}